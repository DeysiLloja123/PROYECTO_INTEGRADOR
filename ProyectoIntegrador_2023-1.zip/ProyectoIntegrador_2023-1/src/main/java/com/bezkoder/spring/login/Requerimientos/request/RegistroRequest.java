package com.bezkoder.spring.login.Requerimientos.request;

import java.util.Set;
import javax.validation.constraints.*;
 
public class RegistroRequest {
	
    @NotBlank
    private String usuario;
    
    @NotBlank
    @Size(max = 50)
    @Email
    private String correo;
   
    @NotBlank
    @Size(min = 8, max =10)
    private String password;
  
    public String getUsuario() {
        return usuario;
    }
 
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
 
    public String getCorreo() {
        return correo;
    }
 
    public void setCorreo(String correo) {
        this.correo = correo;
    }
 
    public String getPassword() {
        return password;
    }
 
    public void setPassword(String password) {
        this.password = password;
    }
}
